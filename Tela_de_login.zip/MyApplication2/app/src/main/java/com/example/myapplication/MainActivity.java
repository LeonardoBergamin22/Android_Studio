package com.example.myapplication;

import static com.example.myapplication.R.id.edt_user;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity{

    String login  = "leo";
    String senha  = "123";
    EditText edt_user, edt_senha;

    Button btn_logar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edt_user = findViewById(R.id.edt_user);
        edt_senha = findViewById(R.id.edt_senha);
        btn_logar = findViewById(R.id.btn_logar);
    }

    public void logar(View v){
        String user = String.valueOf(edt_user.getText());
        String password = String.valueOf(edt_senha.getText());

        if(user.equals(login) && password.equals(senha)){
            Intent logar = new Intent(this, Menu.class);
            startActivity(logar);
            finish();

        }else{
        AlertDialog.Builder cxMsg = new AlertDialog.Builder(this);
        cxMsg.setMessage("Usuario ou senha incorrtos");
        cxMsg.setNeutralButton("ok", null);
        cxMsg.show();
        }
    }
}